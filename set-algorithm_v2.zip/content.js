// ================================
// Set Algorithm - content.js
// ================================

let isProcessing = false;
let lastPackageName = DEFAULT_PACKAGE;

function getVideoCandidates() {
    return Array.from(
        document.querySelectorAll(
            "ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer"
        )
    );
}

function extractVideoText(video) {
    const title =
        video.querySelector("h3, h4, yt-formatted-string, #video-title, #title")?.innerText || "";
    const meta =
        video.querySelector("#metadata, #channel-name, #text")?.innerText || "";
    return [title, meta, video.innerText].join("\n");
}

function applyPackageFilter(packageName) {
    const videos = getVideoCandidates();
    let hiddenCount = 0;
    let visibleCount = 0;

    videos.forEach(video => {
        if (!video || !video.isConnected) {
            return;
        }

        const text = extractVideoText(video);
        const score = calculateScore(text, packageName);

        if (score <= 0) {
            video.style.display = "none";
            video.dataset.saProcessed = "1";
            hiddenCount += 1;
        } else {
            video.style.display = "";
            video.dataset.saProcessed = "1";
            visibleCount += 1;
        }
    });

    if (hiddenCount > 0 || visibleCount > 0) {
        console.log(`[Set Algorithm] ${packageName}: ${hiddenCount}개 숨김, ${visibleCount}개 유지`);
    }
}

function getSelectedPackage() {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
        return new Promise(resolve => {
            chrome.storage.local.get(["selectedPackage"], result => {
                resolve(result.selectedPackage || DEFAULT_PACKAGE);
            });
        });
    }

    return Promise.resolve(DEFAULT_PACKAGE);
}

async function runSetAlgorithm() {
    if (isProcessing) {
        return;
    }

    isProcessing = true;
    const packageName = await getSelectedPackage();

    if (packageName !== lastPackageName) {
        lastPackageName = packageName;
    }

    applyPackageFilter(packageName);
    isProcessing = false;
}

createObserver(runSetAlgorithm);
window.addEventListener("load", runSetAlgorithm);

if (typeof chrome !== "undefined" && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === "local" && changes.selectedPackage) {
            runSetAlgorithm();
        }
    });
}

console.log("Set Algorithm 실행됨");