const packageModule = typeof require === "function" ? require("./packages.js") : null;
const PACKAGE_CONFIG_LOCAL = typeof PACKAGE_CONFIG !== "undefined" ? PACKAGE_CONFIG : (packageModule && packageModule.PACKAGE_CONFIG) || {};
const DEFAULT_PACKAGE_LOCAL = typeof DEFAULT_PACKAGE !== "undefined" ? DEFAULT_PACKAGE : (packageModule && packageModule.DEFAULT_PACKAGE) || "study";

function normalizeText(text) {
    return String(text || "").toLowerCase();
}

function resolvePackageName(packageName) {
    const normalized = normalizeText(packageName).replace(/[^a-z]/g, "");

    if (normalized === "studypack" || normalized === "study") {
        return "study";
    }

    if (normalized === "workoutpack" || normalized === "workout" || normalized === "fitness") {
        return "workout";
    }

    if (normalized === "developmentpack" || normalized === "development" || normalized === "dev") {
        return "development";
    }

    if (normalized === "readingpack" || normalized === "reading" || normalized === "book") {
        return "reading";
    }

    return DEFAULT_PACKAGE_LOCAL;
}

function getPackageConfig(packageName) {
    const resolvedName = resolvePackageName(packageName);
    return PACKAGE_CONFIG_LOCAL[resolvedName] || PACKAGE_CONFIG_LOCAL[DEFAULT_PACKAGE_LOCAL];
}

function calculateScore(title, packageName = DEFAULT_PACKAGE_LOCAL) {
    const text = normalizeText(title);
    const config = getPackageConfig(packageName);
    let score = 0;

    config.include.forEach(keyword => {
        if (text.includes(normalizeText(keyword))) {
            score += 10;
        }
    });

    config.exclude.forEach(keyword => {
        if (text.includes(normalizeText(keyword))) {
            score -= 20;
        }
    });

    return score;
}

if (typeof window !== "undefined") {
    window.calculateScore = calculateScore;
    window.getPackageConfig = getPackageConfig;
}

if (typeof module !== "undefined") {
    module.exports = {
        calculateScore,
        getPackageConfig,
        resolvePackageName
    };
}