document.addEventListener("DOMContentLoaded", () => {
  const select = document.getElementById("packageSelect");
  const button = document.getElementById("saveButton");

  chrome.storage.local.get(["selectedPackage"], result => {
    const saved = result.selectedPackage || "study";
    if (select) {
      select.value = saved;
    }
  });

  button?.addEventListener("click", () => {
    const packageName = select?.value || "study";
    chrome.storage.local.set({ selectedPackage: packageName }, () => {
      window.close();
    });
  });
});
